// Adiyogi Wellness: pose cards, breathing timer and basic MediaPipe coach
const $ = id => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
$("menuBtn").onclick = () => $("nav").classList.toggle("open");
$("nav").querySelectorAll("a").forEach(a => a.onclick = () => $("nav").classList.remove("open"));

const poses = [
["Mountain Pose (Tadasana)","Stand tall, feet grounded and shoulders relaxed.","standing","mountain pose"],
["Tree Pose (Vrikshasana)","Balance on one leg; place the other foot on calf or thigh, never the knee.","balance","tree pose"],
["Chair Pose (Utkatasana)","Bend knees as if sitting in a chair.","standing","chair pose"],
["Warrior I","Bend the front knee and lift arms overhead.","standing","warrior 1 yoga"],
["Warrior II","Extend arms sideways and bend the front knee comfortably.","standing","warrior 2 yoga"],
["Triangle Pose (Trikonasana)","Keep legs wide and lengthen the torso sideways.","standing","triangle pose yoga"],
["Downward-Facing Dog","Form an inverted V with hands and feet grounded.","floor","downward facing dog yoga"],
["Cobra Pose (Bhujangasana)","Lie on your stomach and gently lift the chest.","floor","cobra pose yoga"],
["Child's Pose (Balasana)","Rest hips toward heels and extend arms forward.","floor","child pose yoga"],
["Cat-Cow Pose","Move gently between rounding and extending your spine.","floor","cat cow yoga"],
["Bridge Pose","Lie on your back, bend knees and gently lift hips.","floor","bridge pose yoga"],
["Seated Forward Bend","Sit with legs forward and hinge gently from hips.","seated","seated forward bend yoga"],
["Easy Pose (Sukhasana)","Sit comfortably cross-legged with a relaxed spine.","seated","easy pose yoga"],
["Lotus Pose (Padmasana)","Never force the knees into this seated pose.","seated","lotus pose yoga"],
["Staff Pose (Dandasana)","Sit tall with legs extended and toes pointing upward.","seated","staff pose yoga"],
["Boat Pose (Navasana)","Balance on sitting bones; lift legs only as comfortable.","seated","boat pose yoga"],
["Pigeon Pose","Open the hips gently and avoid knee strain.","floor","pigeon pose yoga"],
["Seated Twist","Sit tall and rotate gently without forcing the spine.","seated","seated twist yoga"],
["Corpse Pose (Savasana)","Lie on your back and relax the whole body.","floor","savasana yoga"],
["Locust Pose (Salabhasana)","Lie face down and gently lift chest or legs.","floor","locust pose yoga"],
["Bow Pose (Dhanurasana)","Try this backbend only gently if comfortable.","floor","bow pose yoga"],
["Plank Pose","Keep shoulders over wrists and body in a straight line.","floor","plank pose yoga"],
["Side Plank","Support the body on one hand and side of one foot.","floor","side plank yoga"],
["Extended Side Angle","Bend the front knee and lengthen your torso sideways.","standing","extended side angle yoga"],
["Revolved Triangle","Keep a stable stance and do not force the twist.","standing","revolved triangle yoga"],
["Garland Pose (Malasana)","Squat comfortably; support heels if needed.","standing","malasana yoga"],
["Half Moon Pose","Balance on one leg; use a wall for support.","balance","half moon pose yoga"],
["Eagle Pose (Garudasana)","Cross arms and legs only as far as comfortable.","balance","eagle pose yoga"],
["Happy Baby Pose","Lie on your back and hold legs gently.","floor","happy baby pose yoga"]
];
function renderPoses(){
 const q=$("search").value.toLowerCase(), f=$("filter").value;
 const list=poses.filter(p=>(f==="all"||p[2]===f)&&(p[0]+" "+p[1]).toLowerCase().includes(q));
 $("poseGrid").innerHTML=list.map(p=>`<article class="pose"><div class="symbol">✧</div><h3>${p[0]}</h3><p>${p[1]}</p><a target="_blank" rel="noopener" href="https://www.youtube.com/results?search_query=${encodeURIComponent(p[3])}">▶ YouTube tutorial ↗</a></article>`).join("");
}
$("search").oninput=renderPoses;$("filter").onchange=renderPoses;renderPoses();

// Breathing exercise, with a simple cycle counter
let breathTimer=null, breathStart=0;
function breathTick(){
 const [inhale,exhale]=$("pattern").value==="46"?[4,6]:[4,4], elapsed=(Date.now()-breathStart)/1000, phase=elapsed%(inhale+exhale), inPhase=phase<inhale;
 $("cycles").textContent=Math.floor(elapsed/(inhale+exhale));
 $("breathCircle").textContent=inPhase?"Inhale":"Exhale";
 $("breathCircle").classList.toggle("active",inPhase);
 $("breathText").textContent=inPhase?`Breathe in gently · ${Math.ceil(inhale-phase)}s`:`Breathe out slowly · ${Math.ceil(inhale+exhale-phase)}s`;
}
$("breathStart").onclick=()=>{clearInterval(breathTimer);breathStart=Date.now();breathTick();breathTimer=setInterval(breathTick,250);$("breathStart").textContent="Restart breathing";};
$("breathReset").onclick=()=>{clearInterval(breathTimer);breathTimer=null;$("cycles").textContent="0";$("breathCircle").textContent="Ready";$("breathCircle").classList.remove("active");$("breathText").textContent="Press start when you're ready.";$("breathStart").textContent="Start breathing";};

// Camera pose model. The model runs in Chrome; no API key is required.
let stream=null, landmarker=null, raf=null, lastTime=-1;
const video=$("video"), canvas=$("canvas"), c=canvas.getContext("2d");
function feedback(title,msg,level=25,label="Tracking"){
 $("feedbackTitle").textContent=title;$("feedback").textContent=msg;$("meter").style.width=level+"%";$("feedbackLabel").textContent=label;
}
function angle(a,b,d){const x1=a.x-b.x,y1=a.y-b.y,x2=d.x-b.x,y2=d.y-b.y,den=Math.hypot(x1,y1)*Math.hypot(x2,y2);return den?Math.acos(Math.max(-1,Math.min(1,(x1*x2+y1*y2)/den)))*180/Math.PI:0;}
function draw(lm){
 c.clearRect(0,0,canvas.width,canvas.height);const lines=[[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28]];
 c.strokeStyle="#e4bd67";c.lineWidth=3;lines.forEach(([a,b])=>{if(lm[a].visibility>.45&&lm[b].visibility>.45){c.beginPath();c.moveTo(lm[a].x*canvas.width,lm[a].y*canvas.height);c.lineTo(lm[b].x*canvas.width,lm[b].y*canvas.height);c.stroke();}});
 lm.forEach(p=>{if(p.visibility>.45){c.beginPath();c.arc(p.x*canvas.width,p.y*canvas.height,4,0,Math.PI*2);c.fillStyle="#f3d994";c.fill();}});
}
function analyse(lm){
 if(![11,12,23,24,25,26,27,28].every(i=>lm[i].visibility>.45))return ["Move back a little","Keep your full body in the camera frame.",25,"Body partly out of frame"];
 const t=$("target").value, lk=angle(lm[23],lm[25],lm[27]),rk=angle(lm[24],lm[26],lm[28]);
 if(t==="warrior2"){
  if(Math.abs(lm[15].y-lm[11].y)>.14||Math.abs(lm[16].y-lm[12].y)>.14)return ["Extend both arms","Warrior II: stretch both arms out to the sides.",45,"Adjust arms"];
  if(Math.min(lk,rk)>155)return ["Bend the front knee","Warrior II: gently bend the front knee, aligned with your toes.",60,"Adjust stance"];
  return ["Good start!","Relax your shoulders and keep your knee aligned with your toes.",80,"Basic cues look okay"];
 }
 if(t==="chair")return Math.min(lk,rk)>155?["Bend your knees","Chair Pose: bend knees as if sitting in a chair.",45,"Adjust stance"]:["Nice start!","Keep your chest lifted and weight balanced.",80,"Basic cues look okay"];
 if(t==="tadasana")return Math.abs(lm[11].y-lm[12].y)>.08?["Level your shoulders","Mountain Pose: stand tall and relax your shoulders.",55,"Small adjustment"]:["Stand tall","Relax shoulders and distribute weight evenly.",80,"Basic cues look okay"];
 if(t==="vrikshasana")return Math.abs(lm[27].y-lm[28].y)<.07?["Find your balance","Tree Pose: shift weight to one leg and place the other foot on calf or thigh, not the knee.",45,"Adjust balance"]:["Keep balancing","Fix your gaze and use a wall for support if needed.",70,"Basic balance cue"];
 if(t==="trikonasana")return ["Lengthen your sides","Triangle Pose: keep legs stable and lengthen your torso; don't force your reach.",60,"General guidance"];
 return ["Body detected","Follow a trusted tutorial. Detailed AI checks are not configured for every pose.",55,"General tracking only"];
}
async function loadModel(){
 if(landmarker)return;
 feedback("Loading AI model…","Downloading the pose model on first use. Keep this tab open.",20,"Loading model");
 const vision=await import("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/+esm");
 const files=await vision.FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm");
 landmarker=await vision.PoseLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:"https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",delegate:"CPU"},runningMode:"VIDEO",numPoses:1,minPoseDetectionConfidence:.5,minPosePresenceConfidence:.5,minTrackingConfidence:.5});
}
function frameLoop(){
 if(!stream||!landmarker)return;
 if(video.readyState>=2&&video.currentTime!==lastTime){lastTime=video.currentTime;canvas.width=video.videoWidth;canvas.height=video.videoHeight;try{const r=landmarker.detectForVideo(video,performance.now());if(r.landmarks?.length){draw(r.landmarks[0]);const f=analyse(r.landmarks[0]);feedback(...f);$("status").textContent="Body detected";}else{c.clearRect(0,0,canvas.width,canvas.height);feedback("No body detected","Improve lighting and show your whole body.",15,"Searching");$("status").textContent="Searching…";}}catch(e){console.error(e);}}
 raf=requestAnimationFrame(frameLoop);
}
async function startCamera(){
 $("start").disabled=true;
 try{
  if(!navigator.mediaDevices?.getUserMedia)throw new Error("Camera needs localhost or HTTPS. Open this site through VS Code Live Server.");
  stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:false});video.srcObject=stream;await video.play();$("placeholder").hidden=true;
  await loadModel();$("stop").disabled=false;feedback("Camera is ready","Move into view and hold your selected pose comfortably.",40,"Waiting for body");frameLoop();
 }catch(e){console.error(e);stopCamera();let m=e.message||"Unknown error";if(e.name==="NotAllowedError")m="Camera permission denied. Allow camera access in Chrome site settings.";feedback("Could not start camera",m,10,"Setup error");$("status").textContent="Camera error";}
 finally{$("start").disabled=false;}
}
function stopCamera(){if(raf)cancelAnimationFrame(raf);raf=null;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;c.clearRect(0,0,canvas.width,canvas.height);$("placeholder").hidden=false;$("status").textContent="Camera is off";$("stop").disabled=true;}
$("start").onclick=startCamera;$("stop").onclick=()=>{stopCamera();feedback("Camera stopped","Start the camera whenever you're ready.",10,"Waiting for camera");};
$("target").onchange=()=>feedback("Pose selected","Hold the selected pose comfortably and follow the basic cues.",35,"Ready");
window.addEventListener("pagehide",stopCamera);
